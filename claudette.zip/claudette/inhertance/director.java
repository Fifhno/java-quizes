class school{  
 String name="ES gikongoro";
}  
class director extends school{  
String nameofdirector="regis";  
 public static void main(String args[]){  
   director p=new director();  
   System.out.println("schoolname name is:"+p.name);  
   System.out.println("director's name is:"+p.nameofdirector);  
}  
}  