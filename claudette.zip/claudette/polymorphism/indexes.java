 //overloadingmultiplication program in java


class indexes{  
  void display(int a, int b){
  
  System.out.println("the first index in array is: "+a+"the second index is: "+b);} 
 
  void display(int a,int b, int c){
   System.out.println("the first index in array is: "+a+" --the second index in array is: "+b+" --the 3rd one is: "+c);}  
  
  public static void main(String args[]){  
  indexes obj=new indexes();  
  obj.display(0,1);
  obj.display(0,1,2);  
  
  }  
}  