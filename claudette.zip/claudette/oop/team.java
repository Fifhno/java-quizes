 
class team{  

 String name="arsenal fc"; 
 String position="4th";
 
 public static void main(String args[]){  
   team p=new team();  
   System.out.println("tem name is:"+p.name);  
   System.out.println("team position is:"+p.position);  
   
}  
}  