//java object and class


class bycle{  
 
 int numbers;
 String manufacturer;  

 public static void main(String args[]){  
  
 bycle b=new bycle(); 
  b.numbers=23;
  b.manufacturer="vvvv";
  System.out.println("bycle numbers are: "+b.numbers); 
  System.out.println("manufacturer is: "+b.manufacturer);  
 }  
}  